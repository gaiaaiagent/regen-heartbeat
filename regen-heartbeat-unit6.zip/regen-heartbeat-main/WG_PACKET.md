# WG Packet — Units 2/4/5 (regen-heartbeat): signal-agent + m010 digests + tests

## What shipped
- Added a new Heartbeat character: **`signal-agent`**
- It publishes an **“m010 Reputation Signal (v0 advisory)”** section and a KPI JSON block.
- Unit 4 updates the skill to define an **MCP call sequence** (KOI + Ledger) and KPI math, with strict **no-fabrication** fallback.
- Unit 5 adds a **validator + CI gate** so PRs fail if the digest schema is broken or if non-configured MCP runs fabricate data.

## Key files
- Character: `.claude/characters/regen/signal-agent.character.json`
- Skill: `.claude/skills/signal-agent/SKILL.md`
- Output style: `.claude/output-styles/signal-agent.md`
- Vendored m010 spec: `.claude/contexts/mechanisms/m010-reputation-signal/SPEC.md`
- Validator: `scripts/validate-signal-agent.mjs`
- CI: `.github/workflows/test-signal-agent.yml`
- Sample output: `content/digests/2026/02/04/signal-agent.md`

## How to run (no MCP configured)
Expected output:
- `sources_checked` = false
- counters = 0
- **validator must pass**
Run:
1) Generate digest via the repo’s normal daily pipeline using `--character signal-agent` (same entrypoint Heartbeat already uses)
2) Validate:
   - `npm run test:signal-agent`

## How to run (with MCP configured)
Expected output:
- `sources_checked.koi/ledger` true for successful calls
- non-zero KPIs when KOI/Ledger return items
Validate remains the same:
- `npm run test:signal-agent`

As-of: 2026-02-04
