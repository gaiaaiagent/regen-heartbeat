@README.md

The character JSON definitions live in `.claude/characters/`. Each output style here is generated from those source characters and should be kept in sync if character definitions change.
