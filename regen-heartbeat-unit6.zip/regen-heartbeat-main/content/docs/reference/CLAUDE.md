@README.md

These are the authoritative tool docs. When generating digests or answering technical questions, this is the single source of truth for what each MCP tool does and how to call it correctly.
