#!/usr/bin/env node
import fs from "fs";
import path from "path";

const HB_ROOT = process.cwd();

function fail(msg) {
  console.error(`FAIL: ${msg}`);
  process.exit(1);
}

function ok(msg) {
  console.log(`OK: ${msg}`);
}

function isDir(p) {
  try {
    return fs.statSync(p).isDirectory();
  } catch {
    return false;
  }
}

function listDirs(p) {
  if (!fs.existsSync(p)) return [];
  return fs
    .readdirSync(p)
    .map((d) => path.join(p, d))
    .filter(isDir)
    .map((full) => path.basename(full))
    .sort();
}

function findLatestDigestFile() {
  const digestsRoot = path.join(HB_ROOT, "content", "digests");
  if (!fs.existsSync(digestsRoot)) return null;

  const years = listDirs(digestsRoot);
  for (let yi = years.length - 1; yi >= 0; yi--) {
    const yPath = path.join(digestsRoot, years[yi]);
    const months = listDirs(yPath);
    for (let mi = months.length - 1; mi >= 0; mi--) {
      const mPath = path.join(yPath, months[mi]);
      const days = listDirs(mPath);
      for (let di = days.length - 1; di >= 0; di--) {
        const f = path.join(mPath, days[di], "signal-agent.md");
        if (fs.existsSync(f)) return f;
      }
    }
  }
  return null;
}

function extractJsonBlock(md) {
  const re = /```json\s*([\s\S]*?)\s*```/m;
  const m = md.match(re);
  return m ? m[1] : null;
}

function main() {
  const explicit = process.argv[2];
  const filePath = explicit ? path.resolve(explicit) : findLatestDigestFile();
  if (!filePath) fail("No signal-agent digest file found.");

  const md = fs.readFileSync(filePath, "utf8");

  if (!md.includes("## m010 Reputation Signal (v0 advisory)")) {
    fail("Missing required heading '## m010 Reputation Signal (v0 advisory)'.");
  }
  ok("Heading present");

  const jsonText = extractJsonBlock(md);
  if (!jsonText) fail("No ```json fenced block found.");

  let obj;
  try {
    obj = JSON.parse(jsonText);
  } catch (e) {
    fail(`JSON block is not valid JSON: ${e.message}`);
  }
  ok("JSON parses");

  const requiredTop = [
    "mechanism_id",
    "scope",
    "as_of",
    "signals_emitted",
    "subjects_touched",
    "evidence_coverage_rate",
    "median_event_latency_hours",
    "sources_checked",
    "notes",
  ];

  for (const k of requiredTop) {
    if (!(k in obj)) fail(`Missing JSON key: ${k}`);
  }
  ok("Required JSON keys present");

  if (obj.mechanism_id !== "m010") fail("mechanism_id must be 'm010'.");
  if (obj.scope !== "v0_advisory") fail("scope must be 'v0_advisory'.");

  if (typeof obj.sources_checked !== "object" || obj.sources_checked === null) {
    fail("sources_checked must be an object.");
  }
  const sc = obj.sources_checked;
  for (const k of ["koi", "ledger", "web"]) {
    if (typeof sc[k] !== "boolean") fail(`sources_checked.${k} must be boolean.`);
  }

  // No-fabrication rule when no sources are checked.
  if (!sc.koi && !sc.ledger && !sc.web) {
    if (obj.signals_emitted !== 0) {
      fail("signals_emitted must be 0 when no sources are checked.");
    }
    if (obj.subjects_touched !== 0) {
      fail("subjects_touched must be 0 when no sources are checked.");
    }
    if (obj.evidence_coverage_rate !== 0.0) {
      fail("evidence_coverage_rate must be 0.0 when no sources are checked.");
    }
    if (obj.median_event_latency_hours !== null) {
      fail("median_event_latency_hours must be null when no sources are checked.");
    }
    ok("No-fabrication checks passed (no sources checked)");
  } else {
    ok("Sources checked; no-fabrication zero checks not enforced");
  }

  ok(`Validated: ${filePath}`);
}

main();
