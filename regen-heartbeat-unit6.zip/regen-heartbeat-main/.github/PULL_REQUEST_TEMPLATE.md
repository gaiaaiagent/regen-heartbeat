## Summary
- [ ] Adds/updates `signal-agent` for m010 digests
- [ ] No enforcement / tx behavior (advisory-only)

## Verification (2 minutes)
- [ ] `npm run test:signal-agent` passes
- [ ] Digest output contains:
  - heading: `m010 Reputation Signal (v0 advisory)`
  - KPI JSON block with required keys
- [ ] If MCP is not configured, output shows:
  - `sources_checked` all false
  - counters 0
  - `median_event_latency_hours` null

## Output sample
Paste the generated “m010 Reputation Signal” section + KPI JSON block here.

## Notes
- MCP wiring (KOI + Ledger) should not fabricate when unavailable.
