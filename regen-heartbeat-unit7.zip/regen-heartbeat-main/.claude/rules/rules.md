ALWAYS use the front-end design skill when doing anything front-end or web related.
