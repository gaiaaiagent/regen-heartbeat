@README.md

This skill references the daily template directory at `templates/daily/` and pulls configuration from settings.json, including default template paths and digest output locations. When invoked, it reads the template, gathers all necessary data, and writes the finished digest to the appropriate location in `content/digests/`.
