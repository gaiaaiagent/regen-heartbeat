@README.md

The list of search topics is configured in the settings.json file at the repository root under the `currentEvents.topics` key. To add new topics or adjust search terms, edit that file.
