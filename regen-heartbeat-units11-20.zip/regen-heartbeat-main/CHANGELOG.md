# Changelog

## Unreleased
### Added
- Units 11–20: schema-aligned validator, MCP normalizer, stub-mode runner, CI steps, and verification tooling.

### Notes
- Outputs must follow the "no fabrication" rule when MCP is unavailable.
