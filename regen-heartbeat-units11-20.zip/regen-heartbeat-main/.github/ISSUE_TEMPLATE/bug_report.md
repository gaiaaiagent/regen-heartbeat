---
name: Bug report
about: Report an issue with a digest, validator, or publishing pipeline
title: "[BUG] "
labels: bug
---

## What happened?

## Expected behavior

## Repro
Commands + file paths (offline if possible):

## Output
Paste digest section + KPI JSON block (redact secrets).
