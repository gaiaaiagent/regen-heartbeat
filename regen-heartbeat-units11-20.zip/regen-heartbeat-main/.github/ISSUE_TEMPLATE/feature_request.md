---
name: Feature request
about: Request a new agent/digest feature or mechanism integration
title: "[FEATURE] "
labels: enhancement
---

## What do you want to add?

## Why?

## Acceptance criteria
