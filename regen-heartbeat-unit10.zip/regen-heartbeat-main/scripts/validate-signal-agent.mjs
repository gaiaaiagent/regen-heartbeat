#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

const repoRoot = process.cwd();
const target = process.env.SIGNAL_AGENT_DIGEST
  ?? path.join(repoRoot, "content", "digests", "2026", "02", "04", "signal-agent.md");

if (!fs.existsSync(target)) {
  console.error(`Missing digest file: ${target}`);
  process.exit(2);
}

const md = fs.readFileSync(target, "utf8");

function requireIncludes(s, needle) {
  if (!s.includes(needle)) {
    console.error(`Missing required marker: ${needle}`);
    process.exit(3);
  }
}

requireIncludes(md, "## m010 Reputation Signal (v0 advisory)");
requireIncludes(md, "```json");
requireIncludes(md, '"mechanism_id": "m010"');

const match = md.match(/```json\s*([\s\S]*?)\s*```/);
if (!match) {
  console.error("Missing JSON code block");
  process.exit(4);
}

let obj;
try {
  obj = JSON.parse(match[1]);
} catch (e) {
  console.error("Invalid JSON in code block");
  console.error(e?.message ?? e);
  process.exit(5);
}

const requiredKeys = [
  "mechanism_id",
  "scope",
  "as_of",
  "signals_emitted",
  "subjects_touched",
  "evidence_coverage_rate",
  "median_event_latency_hours",
  "sources_checked"
];

for (const k of requiredKeys) {
  if (!(k in obj)) {
    console.error(`Missing KPI key: ${k}`);
    process.exit(6);
  }
}

const sc = obj.sources_checked ?? {};
const allFalse =
  (sc.koi === false || sc.koi === undefined) &&
  (sc.ledger === false || sc.ledger === undefined) &&
  (sc.web === false || sc.web === undefined);

if (allFalse) {
  const bad =
    obj.signals_emitted !== 0 ||
    obj.subjects_touched !== 0 ||
    obj.evidence_coverage_rate !== 0.0 ||
    obj.median_event_latency_hours !== null;

  if (bad) {
    console.error("No-fabrication violation: sources_checked all false but KPIs are non-zero");
    process.exit(7);
  }
}

console.log("signal-agent digest validation: PASS");
process.exit(0);
