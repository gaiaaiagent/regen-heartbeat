@README.md

The settings.json file at the repository root contains default template paths and configuration for each cadence. When a template is not explicitly specified, those defaults are used.
