# Signal Agent — {{date}}

## m010 Reputation Signal (v0 advisory)
<!-- source: koi, ledger -->

- as of {{date}}
- canonical spec: `.claude/contexts/mechanisms/m010-reputation-signal/SPEC.md`

What this is / what it is not (v0):
- (filled by skill)

### Candidate subjects

| subject_type | subject_id | reason | evidence_links |
|---|---|---|---|
| none | none | no candidates found | [] |

### m010 metrics (JSON)

```json
{
  "mechanism_id": "m010",
  "scope": "v0_advisory",
  "as_of": "{{date}}",
  "signals_emitted": 0,
  "subjects_touched": 0,
  "evidence_coverage_rate": 0.0,
  "median_event_latency_hours": null,
  "sources_checked": {"koi": false, "ledger": false, "web": false},
  "notes": ""
}
```
