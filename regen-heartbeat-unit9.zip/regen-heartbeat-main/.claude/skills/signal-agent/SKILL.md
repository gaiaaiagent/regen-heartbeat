---
name: signal-agent
description: m010 reputation signal digest section with KPI JSON (v0 advisory)
---

Read:
- `.claude/contexts/mechanisms/m010-reputation-signal/SPEC.md`

Produce a markdown section titled "m010 Reputation Signal (v0 advisory)" and a JSON block with:
mechanism_id, scope, as_of, signals_emitted, subjects_touched, evidence_coverage_rate, median_event_latency_hours, sources_checked, notes.

If KOI/Ledger/Web are unavailable, report zeros and set sources_checked flags to false.

Write to `content/digests/YYYY/MM/DD/signal-agent.md` with frontmatter similar to the daily digest.


Before producing output, run `node scripts/mcp-diagnose.mjs` and include a one-line header:
`MCP connectivity: KOI=<true|false>, LEDGER=<true|false>`.
Use the JSON output to set sources_checked.koi and sources_checked.ledger (do not guess).
