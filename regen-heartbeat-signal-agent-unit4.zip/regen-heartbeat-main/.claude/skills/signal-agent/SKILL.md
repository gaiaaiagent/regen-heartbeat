---
name: signal-agent
description: m010 reputation signal digest section with KPI JSON (v0 advisory) — MCP-enabled (KOI + Ledger)
---

## Canon
Read and treat as authoritative:
- `.claude/contexts/mechanisms/m010-reputation-signal/SPEC.md`

## MCP data sources (preferred)
If MCP servers are configured, use them. Expected server names (from regen-ai-claude defaults):
- `regen-koi` (KOI knowledge)
- `regen-ledger` (Regen chain)

If any MCP call fails or tools are unavailable, **do not fabricate**. Set all counters to 0 and:
`sources_checked: {koi:false, ledger:false, web:false}`.

## Time window
- Default: last 7 days relative to the run date.

## KOI (knowledge) calls
Goal: collect evidence items with timestamps + URLs.
Use one or more of the following tool patterns (names may vary by client; adapt to the discovered KOI tools):

1) Hybrid search (date-filtered):
- query terms: `reputation OR endorsement OR verifier OR methodology OR credit class OR ecocredit OR marketplace`
- filters: last 7 days, sources: forum + github + docs if available

2) Weekly summary (if available): pull “governance + registry + on-chain” summaries for the same window.

Capture from each KOI item:
- `title` / `source`
- `url`
- `timestamp` (or best available published/created time)
- any extracted subject identifiers (see “Subject extraction” below)

## Ledger (chain) calls
Goal: collect on-chain evidence items with timestamps.
Use one or more of the following:
- Governance: list proposals in deposit/voting/passed states; for each capture `id`, `title`, `submit_time`/`voting_start` (whichever exists)
- Ecocredit/Marketplace pulse: list recent credit batches / sell orders / marketplace activity if the tools exist

Capture:
- `module` (gov/ecocredit/marketplace/etc.)
- `id` (proposal id, batch denom/id, order id, etc.)
- `timestamp` (submit/start time or equivalent)

## Subject extraction
We are producing **candidate m010 subjects**, not enforcing reputation.
Extract up to 10 candidate subjects from KOI + ledger evidence using this priority order:
1) Explicit identifiers already present in evidence (class id, project id, batch denom/id, proposal id, address)
2) “Best-effort” subject mention with a link back to the evidence URL

Subject tuple:
- `subject_type`: one of `CreditClass | Project | Verifier | Methodology | Address`
- `subject_id`: an ID or URL/slug if no canonical ID is available
- `reason`: 1–2 sentences grounded in evidence

## KPI computation (required JSON fields)
Compute:
- `signals_emitted`: number of candidate subjects emitted (max 10)
- `subjects_touched`: number of distinct `(subject_type, subject_id)` in the emitted list
- `evidence_coverage_rate`:
  - For each emitted subject, attach evidence links.
  - A subject counts as “covered” if it has ≥1 KOI evidence link, and (if the reason references on-chain state) ≥1 ledger evidence item.
  - coverage_rate = covered / signals_emitted (0 if signals_emitted == 0)
- `median_event_latency_hours`:
  - For each emitted subject, take the newest attached evidence timestamp (KOI or ledger).
  - latency_hours = (now - evidence_timestamp) in hours
  - median across emitted subjects; `null` if none have timestamps

Also output:
- `sources_checked`: {koi: bool, ledger: bool, web: bool} (web should remain false unless Heartbeat includes a web-fetch tool in this run)

## Output format (must include both)
### 1) Markdown section
Title: `m010 Reputation Signal (v0 advisory)`

Include:
- `as of YYYY-MM-DD`
- Reference to canonical spec path: `mechanisms/m010-reputation-signal/SPEC.md`
- “What this is / What it is not (v0)” in ≤6 lines
- Table (max 10 rows): `subject_type | subject_id | reason | evidence_links`

If no candidates:
- Include a single row: `none | none | no candidates found in window | []`

### 2) JSON block
Emit exactly:

```json
{
  "mechanism_id": "m010",
  "scope": "v0_advisory",
  "as_of": "YYYY-MM-DD",
  "signals_emitted": 0,
  "subjects_touched": 0,
  "evidence_coverage_rate": 0.0,
  "median_event_latency_hours": null,
  "sources_checked": {"koi": false, "ledger": false, "web": false},
  "notes": ""
}
```

Populate with real values only if sourced.
