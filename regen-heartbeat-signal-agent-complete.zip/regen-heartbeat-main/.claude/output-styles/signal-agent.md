# Signal Agent

Audit-style. Numeric-first. Source-grounded. No enforcement implied.
